# 🌿 Serenova — AI Mental Health Companion

> A conversational AI chatbot that detects emotional tone, provides empathetic responses, and tracks mood over sessions.

[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://your-app.streamlit.app)

---

## Features

- 🤖 **LLM-powered empathetic responses** via Claude (Groq API (Free))
- 🎭 **Real-time sentiment & mood detection** from every message
- 📊 **Session mood tracking** with interactive Plotly charts
- 💡 **Dynamic coping strategies** updated based on conversation context
- 🌿 **Clean white UI** with calming sage green aesthetic

## Tech Stack

`Python` · `Streamlit` · `Groq API (Free)` · `Plotly` · `NLP`

## Local Setup

```bash
git clone https://github.com/sonikadeshwal/serenova-mental-health-companion
cd serenova-mental-health-companion
pip install -r requirements.txt
```

Add your API key to `.streamlit/secrets.toml`:
```toml
GROQ_API_KEY = "gsk_your-key-here"
```

Run:
```bash
streamlit run app.py
```

## Deploy on Streamlit Cloud

1. Push this repo to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Connect your repo → set `app.py` as main file
4. Add `GROQ_API_KEY` in **Secrets** settings
5. Deploy 🚀

---

*Serenova is an AI companion and not a substitute for professional mental health care.*  
*Crisis helpline (India): iCall — 9152987821*
